JRankMirrors
------------
JRankMirrors allows you to get easily the five fastest Arch Linux mirrors.
It uses latest mirrors provided here : https://www.archlinux.org/mirrors/status/ and filter by fetching the
core.db.tar.gz file for each mirror.